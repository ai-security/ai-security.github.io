#include "matrix.h"


#ifndef QC_MDPC_H
#define QC_MDPC_H
typedef struct qc_mdpc
{
	unsigned short* row;
	int n0, p, w, t, n, k, r;
}*mdpc;

#define SECURITY80 // choose one of these two security levels
//#define SECURITY128

#define N0  2
#ifdef SECURITY80
#define T  84
#define P  4801
#define W  90
#endif
#ifdef SECURITY128
#define T  134
#define P  9857
#define W  142
#endif
#define K (N0 - 1) * P

void getErrorVectorEnc(int len, int t, unsigned short* error);
int get_max(int* vec, int len);
void decodeH(unsigned short* word, unsigned short *H);

#endif