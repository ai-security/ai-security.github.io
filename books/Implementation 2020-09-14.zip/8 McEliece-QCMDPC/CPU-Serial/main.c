#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"
#include "qc_mdpc.h"
#include "mceliece.h"
#include <stdint.h>

int main(int argc, char const *argv[])
{
	FILE* fp1, * fp2;		
	printf("QC-MDPC McEliece Encryption Cryptosystem\n");
	uint8_t opt = 0;

	for (int i = 1; i < argc;) {
		if (strcmp(argv[i], "-opt") == 0) {
			opt = atoi(argv[i + 1]);
			i += 2;
		}
		else {
			//help_message();
			return -1;
		}
	}
	printf("Option selected: %u \n", opt);
	
	if(opt == 1)
	{
		mcc crypt = mceliece_init(N0, P, W, T);
		bin_matrix H = parity_check_matrix(crypt->code);
		printf("%d %d %d %d\n", H->rows, H->cols, crypt->public_key->rows, crypt->public_key->cols);
		fopen_s(&fp1, "Private_Key.txt", "w+t");	// G is in crypt->public_key
		fwrite(H->data, sizeof(unsigned short), H->rows * H->cols, fp1);
		fclose(fp1);
			//print_matrix(H);
		fopen_s(&fp2, "Public_Key.txt", "w+t");	// G is in crypt->public_key
		fwrite(crypt->public_key->data, sizeof(unsigned short), crypt->public_key->rows * crypt->public_key->cols, fp2);
		
		fclose(fp2);
		printf("Keys Generated...\n");
	}
	else if(opt == 2)
	{
		unsigned short* temp = (unsigned short*)malloc(N0 * P * sizeof(unsigned short));
		unsigned short* error = (unsigned short*)malloc(N0 * P * sizeof(unsigned short));
		unsigned short* msg = (unsigned short*)malloc(K * sizeof(unsigned short));
		unsigned short* G = (unsigned short*)malloc(P * 2 * P * sizeof(unsigned short));
		unsigned short check = 0;
		unsigned short* cipher = (unsigned short*)malloc(2* P * sizeof(unsigned short));
		unsigned short* H = (unsigned short*)malloc(P * 2 * P * sizeof(unsigned short));
		unsigned short* msg_dec = (unsigned short*)malloc(K * sizeof(unsigned short));

		for (int i = 0; i < N0 * P; i++) temp[i] = 0;	
		for (int i = 0; i < N0 * P; i++) error[i] = 0;
		for (int i = 0; i < K; i++) msg[i] = 0;
		for (int i = 0; i < P * 2 * P; i++) G[i] = 0;
		for (int i = 0; i < 2 * P; i++) cipher[i] = 0;
		for (int i = 0; i < P * 2 * P; i++) H[i] = 0;
		for (int i = 0; i < K; i++) msg_dec[i] = 0;

			// 1. Obtain the public key from file
		fopen_s(&fp2, "Public_Key.txt", "r+t");
		fread_s(G, P * 2 * P * sizeof(unsigned short), sizeof(unsigned short), P * 2 * P, fp2);
	
			// Encrypt using public key
			// 2. Generate error vector, e
		getErrorVectorEnc(N0 * P, T, error);
			// 3. Perform cipher = mG + e
		matMulEnc(msg, G, temp);						
		addMatrixEnc(temp, error, cipher);

		fclose(fp2);
		printf("Encrypted...\n");

/********************************************************/
			// 1. Obtain the private key from file
		fopen_s(&fp1, "Private_Key.txt", "r+t");
		fread_s(H, P * 2*P * sizeof(unsigned short), sizeof(unsigned short), P * 2 * P, fp1);
			// 2. Decode the syndrome through bit-flipping algorithm
		decodeH(cipher, H);
			// 3. Extract the results from decoded matrix		
		extracDec(cipher, msg_dec, K - 1);

		fclose(fp1);
		printf("Decrypted...\n");

			// Check the decrypted results against the msg.
		for(int i=0; i<K; i++)
			if (msg[i] != msg_dec[i])
				check = 1;			
			
		if(!check)printf("decrypted correctly!\n");
		else printf("decrypted wrongly\n");
	}
	
	return 0;
}