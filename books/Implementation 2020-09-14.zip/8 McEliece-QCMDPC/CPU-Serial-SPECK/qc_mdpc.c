#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include "qc_mdpc.h"
#include "matrix.h"

//Generate a random error vector of length len of weight t using SPECK block cipher in CTR mode
void getErrorVectorEnc(int length, int t, unsigned short* error)
{
	uint8_t nonce[16], key[16], len = 16;// Enc 128-bit
	//Store output as 16-bit array. This is because the random
	//positions in error vector span across 0-9601 (SECURITY80) or 0-19714 (SECURITY128). 16-bit is enough to hold such values.
	uint16_t out[16];

	uint32_t i, j;
	for (i = 0; i < 16; i++) key[i] = i;// initialize key

	nonce[0] = 0x26;	nonce[1] = 0x6d;	nonce[2] = 0x61;
	nonce[3] = 0x64;	nonce[4] = 0x65;	nonce[5] = 0x20;
	nonce[6] = 0x69;	nonce[7] = 0x74;	nonce[8] = 0x20;
	nonce[9] = 0x65;	nonce[10] = 0x71;	nonce[11] = 0x75;
	nonce[12] = 0x69;	nonce[13] = 0x76;	nonce[14] = 0x61;
	nonce[15] = 0x6f;

	int weight = 0;
	int idx = 0;
	while (weight < t)
	{
		// Obtain a series of pseudorandom numbers generated through SPECK in CTR mode. Note that each time we involve the encryption, 8*16=128-bit values are encrypted.
		crypto_stream_speck128128ctr_ref(out, len, nonce, key);
		for (i = 0; i < len / 2; i++) // Check each value
		{
			idx = out[i];
			if (idx > length) continue;// skip, too big

			//printf("idx: %d\t", idx);
			if (!error[idx])
			{
				error[idx] = 1;
				weight++;
			}
		}
		// If there is not enough random positions generated, increase the nonce (CTR value) and repeat.
		nonce[0]++;
	}
}

//Returns the maximum element of the array
int get_max(int* vec, int len)
{
	int max = vec[0];
	int i;
	for(i = 1; i < len; i++)
	{
		if(vec[i] > max)
		{
			max = vec[i];
		}
	}
	return max;
}

//Decoding the codeword from private key H
void decodeH(unsigned short *word, unsigned short *H)
{		
	unsigned short* syn = (unsigned short*)malloc(P * sizeof(unsigned short));
	//bin_matrix syn = matMulDec(H, word);
	matMulDec(H, word, syn);
	int limit = 10;
	int delta = 5;
	int i, j, k, x;
	int* unsatisfied;
	unsatisfied = (int*)malloc(2*P * sizeof(int));
	for (i = 0; i < limit; i++)
	{
		//printf("Iteration: %d\n", i);

		for (x = 0; x < 2 * P; x++)
		{
			unsatisfied[x] = 0;
		}
		for (j = 0; j < 2 * P; j++)
		{
			for (k = 0; k < P ; k++)
			{				
				if(H[k*2*P + j]==1)
				{					
					if(syn[k]==1)
					{
						unsatisfied[j] = unsatisfied[j] + 1;
					}
				}
			}
		}
		// printf("No. of unsatisfied equations for each bit: \n");
		// for(int idx = 0; idx < word->cols; idx++)
		// {
		// 	printf("b%d: %d \n", idx, unsatisfied[idx]);
		// }
		int b = get_max(unsatisfied, 2 * P) - delta;
		for (j = 0; j < 2 * P; j++)
		{
			if (unsatisfied[j] >= b)
			{
				// flip the bit
				word[j] = word[j] ^ 1;
				unsigned short* temp = (unsigned short*)malloc(P * sizeof(unsigned short));
				mat_splice2(H, P, j, temp);
				matvecAddDec(syn, temp);
			}
		}
		// printf("Syndrome: ");
		// print_matrix(syn);
		// printf("\n");
		//printf("Iteration: %d\n", i);
		
		int flag = 1;
		for (j = 0; j < P; j++)
		{
			if (syn[j] != 0)
				flag = 0;								
		}
		
		if (flag)
			return;		
	}
	printf("Decoding failure...\n");
	exit(0);
}


