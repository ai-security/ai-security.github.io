#include "qc_mdpc.h"
#include "matrix.h"
#include "utility.h"


#ifndef MCELIECE_H
#define MCELIECE_H

#define N0  2
#define T  84
#define P  4801 // r = p in QC-MDPC McEliece
#define W  90
#define K (N0 - 1) * P

typedef struct mceliece
{
   mdpc code;
   bin_matrix public_key;
}*mcc;

mcc mceliece_init(int n0, int p, int w, int t);
void delete_mceliece(mcc A);
bin_matrix get_error_vector(int len, int t);
bin_matrix encrypt(bin_matrix msg, mcc crypt);
bin_matrix decrypt(bin_matrix word, mcc crypt);
#endif