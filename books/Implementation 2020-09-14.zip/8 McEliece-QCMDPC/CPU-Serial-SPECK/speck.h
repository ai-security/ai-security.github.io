#include <stdio.h>
#include <stdint.h>

int crypto_stream_speck128128ctr_ref(
    unsigned char* out,
    unsigned long long outlen,
    const unsigned char* n,
    const unsigned char* k
);