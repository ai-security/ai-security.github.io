#include <stddef.h>

#ifndef UTIL
#define UTIL

void* safe_malloc(size_t n);

#endif