#include "speck.h"
#define ROR64(x,r) (((x)>>(r))|((x)<<(64-(r))))
#define ROL64(x,r) (((x)<<(r))|((x)>>(64-(r))))
#define R(x,y,k) (x=ROR64(x,8), x+=y, x^=k, y=ROL64(y,3), y^=x)
#define RI(x,y,k) (y^=x, y=ROR64(y,3), x^=k, x-=y, x=ROL64(x,8))

int Encrypt(uint64_t* u, uint64_t* v, uint64_t key[])
{
    uint64_t i, x = *u, y = *v;

    for (i = 0; i < 32; i++) R(x, y, key[i]);

    *u = x; *v = y;

    return 0;
}



int Decrypt(uint64_t* u, uint64_t* v, uint64_t key[])
{
    int i;
    uint64_t x = *u, y = *v;

    for (i = 31; i >= 0; i--) RI(x, y, key[i]);

    *u = x; *v = y;

    return 0;
}



int ExpandKey(uint64_t K[], uint64_t key[])
{
    uint64_t i, B = K[1], A = K[0];

    for (i = 0; i < 32; i++) {
        key[i] = A; R(B, A, i);
    }

    return 0;
}

int crypto_stream_speck128128ctr_ref(
    unsigned char* out,
    unsigned long long outlen,
    const unsigned char* n,
    const unsigned char* k
)
{
    uint64_t i, nonce[2], K[2], key[32], x, y, t;
    unsigned char* block = (unsigned char*) malloc(16*sizeof(unsigned char));

    if (!outlen) { free(block); return 0; }

    nonce[0] = ((uint64_t*)n)[0];
    nonce[1] = ((uint64_t*)n)[1];

    for (i = 0; i < 2; i++) K[i] = ((uint64_t*)k)[i];

    ExpandKey(K, key);
    
    t = 0;
    while (outlen >= 16) {
        x = nonce[1]; y = nonce[0]; nonce[0]++;
        Encrypt(&x, &y, key);
        ((uint64_t*)out)[1 + t] = x;
        ((uint64_t*)out)[0 + t] = y;
        t += 2;
        outlen -= 16;
    }

    // Handle remaining bit < 128-bit (16 bytes)
    if (outlen > 0) {
        x = nonce[1]; y = nonce[0];
        Encrypt(&x, &y, key);
        ((uint64_t*)block)[1] = x; ((uint64_t*)block)[0] = y;
        for (i = 0; i < outlen; i++) out[i + 8 * t] = block[i];
    }
    return 0;
}