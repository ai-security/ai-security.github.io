#include <iostream>
#include <time.h>//#include <sys/time.h>
#include <sys/stat.h>
#include <windows.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "ntruenc_inv.h"
#include "publicKey.h"


// The data needed to convert a number mod 3 to a number in the range: -1..1.
static short neg_mod_3_data_cpu[5] = { 1, -1, 0, 1, -1 };
// The variable used to convert a number mod 3 to a number in the range: -1..1.
static short* neg_mod_3_cpu = &neg_mod_3_data_cpu[2];
static unsigned char data_dec_data[3] = { 0, 1, 1 };
static unsigned char* data_dec = &data_dec_data[1];
uint32_t ind(int x, int y, uint32_t deg)
{
	if (x > y)	return (x - y);
	else if (x == y) return 0;
	else return (deg + (x - y));
}
/**
* Makes number modulo 3 in the range: -1..1.
*/
#define ntruenc_neg_mod_3(a)	(neg_mod_3[(a) % 3])
#define ntruenc_neg_mod_3_cpu(a)	(neg_mod_3_cpu[(a) % 3])

void poly_mul_mod_q(short* res, short* polyA, short* polyB)
{
	uint16_t i = 0, j = 0;

	for (i = 0; i < NTRU_N_112; i++)
	{
		for (j = 0; j < NTRU_N_112; j++)
		{
			res[i] += polyA[j] * polyB[ind(i, j, NTRU_N_112)];
			res[i] &= NTRU_Q_112 - 1; // technique to mod q when q is power of 2
			res[i] |= 0 - (res[i] & (1 << (NTRU_S112_Q_BITS - 1)));
		}
	}
}

/**
 * Invert the vector mod q.
 *
 * fq  : The inverse mod q.
 * f   : The vector to invert.
 * 
 */
int NTRUENC_MOD_INV_Q(short* fq, short* f)
{
	int ret;
	int i,j;
	short t[NTRU_N_112], t2[NTRU_N_112];
	
	for (j = 0; j < NTRU_N_112; j++) {
		t[j] = 0; t2[j] = 0;
	}
	ret = NTRUENC_MOD_INV_2(fq, f);
	if (ret != 0) return ret;
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < NTRU_N_112; j++) {
			t[j] = 0; t2[j] = 0;
		}
		poly_mul_mod_q(t, f, fq);
		t[0] += 2;
		poly_mul_mod_q(t2, fq, t);
		for (j = 0; j < NTRU_N_112; j++) fq[j] = t2[j];
	}
	
	return 0;
}

// Generate random vector {v, 0 -v}
// a	: the randomized random vector
// df1	: maximum number of positive values
// df2	: maximum number of negative values
// v	: the value to be bounded
int gen_random(short* a, int df1, int df2, short v)
{
	int ret = 0;
	int i;
	uint32_t r[NTRU_N_112];
	unsigned short j;
	short t;
	srand(time(0));
	// Generate an array of random indices. 
	for (i = 0; i < NTRU_N_112; i++) r[i] = rand();
	for (i = 0; i < NTRU_N_112; i++) a[i] = 0;

	/* Put in the require number values: v and -v */
	for (i = 0; i < df1; i++)
		a[i] = v;
	for (; i < df1 + df2; i++)
		a[i] = NTRU_Q_112 - v;	// represent -v

	/* Randomly mix the values. */
	for (i = NTRU_N_112 - 1; i > 0; i--)
	{
		// generate random indices bounded by N
		j = r[i] % NTRU_N_112;	
		// then swap the value of a[i] with value in random index
		t = a[i];
		a[i] = a[j];
		a[j] = t;
	}

end:
	return ret;
}


// Generate public (h) and private key (f).
//   f' = (random array * p) mod q
//   f  = 1 + p.f' mod q
//   t  = f^-1 mod q --> finding the inverse of f mod q
//   g  = (random array mod q) * p
//   h  = g.t --> polynomial multiplication
//
// f	: The random private value f.
// h	: The public value h.
// t	: The temprorary buffer to use in generation.  
int keygeneration(short* f, short* h, short* t)
{
	int ret, i;
	for (i = 0; i < NTRU_N_112; i++) t[i] = 0;
	ret = gen_random(f, NTRU_DF_112, NTRU_DF_112, 3);
	if (ret != 0) return ret;
	f[0] += 1;
	ret = NTRUENC_MOD_INV_Q(t, f);

	if (ret != 0) {
		printf("no inverse!!\n\n\n");  return ret;
	}

	short* g = &t[NTRU_N_112];	
	ret = gen_random(g, NTRU_DG_112, NTRU_DG_112, 3);
	if (ret != 0) {
		printf("no random!!\n\n\n");  return ret;
	}
	poly_mul_mod_q(h, t, g);
	return 0;
}

// Encode the original plaintext into polynomial form
// data		: original plaintext meassage
// len		: length of the plaintext message to be encoded, in byte
// n		: degree of polynomial (N)
// m		: encoded plaintext 
static int8_t ntruenc_encode_msg(uint8_t* data, int len, int n, int16_t* m)
{
	int ret = 0;
	int i, j;

	unsigned char* l = (unsigned char*)& len;
	int zlen;

	if ((len + 2) * 8 > n)
	{
		ret = 0;
		return -1;
	}
	zlen = (n - ((len + 2) * 8)) / 8;

	for (i = 0; i < 2; i++)
	{
		for (j = 0; j < 8; j++)
			m[i * 8 + j] = (((l[i] >> j) & 1) << 1) - 1;
	}
	m += 2 * 8;
	for (i = 0; i < len; i++)
	{
		for (j = 0; j < 8; j++)
			m[i * 8 + j] = (((data[i] >> j) & 1) << 1) - 1;
	}
	m += len * 8;
	for (i = 0; i < zlen; i++)
	{
		for (j = 0; j < 8; j++)
			m[i * 8 + j] = 0;
	}
	m += zlen * 8;
	switch ((n - ((len + 2) * 8)) & 7)
	{
	case 7:
		m[6] = 0;
	case 6:
		m[5] = 0;
	case 5:
		m[4] = 0;
	case 4:
		m[3] = 0;
	case 3:
		m[2] = 0;
	case 2:
		m[1] = 0;
	case 1:
		m[0] = 0;
	default:
		break;
	}
}

// Decode the plaintext from polynomial form into normal representation
// m		: encoded plaintext 
// data		: original plaintext meassage
static int8_t ntruenc_decode_msg(int16_t* m, int n, uint8_t* data)
{
	int ret = 0;
	int i, j;
	short dlen;
	unsigned char* l = (unsigned char*)& dlen;
	short *zero;
	int zlen;
	char r = 0;

	for (i = 0; i < 2; i++)
	{
		l[i] = data_dec[m[(i * 8) + 0]];
		for (j = 1; j < 8; j++)
			l[i] |= data_dec[m[(i * 8) + j]] << j;
	}

	if (data == NULL)
		goto end;

	if ((dlen + 2) * 8 > n)
	{
		ret = -1;
		dlen = n - 10;
	}

	zlen = (n - (dlen + 2) * 8) / 8;
	zero = (short*) malloc(zlen * sizeof(short));
	if (zero == NULL)
	{
		ret = -1;
		goto end;
	}

	m += 2 * 8;
	for (i = 0; i < dlen; i++)
	{
		r |= m[(i * 8) + 0] == 0;
		data[i] = data_dec[m[(i * 8) + 0]];
		for (j = 1; j < 8; j++)
		{
			r |= m[(i * 8) + j] == 0;
			data[i] |= data_dec[m[(i * 8) + j]] << j;
		}
	}
	m += dlen * 8;
	for (i = 0; i < zlen; i++)
	{
		r |= m[(i * 8) + 0] != 0;
		zero[i] = data_dec[m[(i * 8) + 0]];
		for (j = 1; j < 8; j++)
		{
			r |= m[(i * 8) + j] != 0;
			zero[i] |= data_dec[m[(i * 8) + j]] << j;
		}
	}
	m += zlen * 8;
	switch ((n - ((dlen + 2) * 8)) & 7)
	{
	case 7:
		r |= m[6] != 0;
	case 6:
		r |= m[5] != 0;
	case 5:
		r |= m[4] != 0;
	case 4:
		r |= m[3] != 0;
	case 3:
		r |= m[2] != 0;
	case 2:
		r |= m[1] != 0;
	case 1:
		r |= m[0] != 0;
	default:
		break;
	}

	if (r)
		return -1;
end:
	return ret;
}

// Truncated polynomial multiplication (sparse) for PolyA and PolyB.
// Then stores the result in res.
// res		: the results
// polyA	: input polynomial A
// polyB	: sparse polynomial with known positions for +1 and -1
// pos		: locations of +1 for polyB
// neg		: locations of -1 for polyB
void sparsePolyMulModQ(int16_t* res, int16_t* polyA, int16_t* polyB, uint16_t deg, uint16_t q, uint16_t* pos, uint16_t* neg)
{
	int zero = 0, negOne = 0, one = 0;
	for (int i = 0; i < deg; i++)
	{
		for (int j = 0; j < NTRU_ONE; j++)
		{
			res[i] += polyA[ind(i, pos[j], deg)];
			res[i] &= NTRU_Q_112 - 1; // technique to mod q when q is power of 2
			res[i] |= 0 - (res[i] & (1 << (NTRU_S112_Q_BITS - 1)));
		}

		for (int j = 0; j < NTRU_NEGONE; j++)
		{
			res[i] -= polyA[ind(i, neg[j], deg)];
			res[i] &= NTRU_Q_112 - 1; // technique to mod q when q is power of 2
			res[i] |= 0 - (res[i] & (1 << (NTRU_S112_Q_BITS - 1)));
		}
	}
}

// Truncated polynomial multiplication (schoolbook) for PolyA and PolyB.
// Then stores the result in res.
// Both poly are 16-bit
// res		: the results
// polyA	: input polynomial A
// polyB	: input polynomial B
// deg		: degree of polynomial
// q		: modulus
void simplePolyMulModQ2(int16_t* res, int16_t* polyA, int16_t* polyB, uint16_t deg, uint16_t q)
{
	uint16_t i = 0, j = 0;
	for (i = 0; i < deg; i++)
	{
		for (j = 0; j < deg; j++)
		{
			res[i] += polyA[j] * polyB[ind(i, j, deg)];
			res[i] &= NTRU_Q_112 - 1; // technique to mod q when q is power of 2
			res[i] |= 0 - (res[i] & (1 << (NTRU_S112_Q_BITS - 1)));
		}
	}
}

//Add two polynomials and stores the result in res.
// Both poly are 16-bit
// res		: the results
// polyA	: input polynomial A
// polyB	: input polynomial B
void simplePolyAddModQ(int16_t* res, int16_t* polyA, int16_t* polyB, uint16_t deg,
	uint16_t q)
{
	uint16_t i = 0;
	for (i = 0; i < deg; i++)
	{
		res[i] = polyA[i] + polyB[i];
		res[i] &= NTRU_Q_112 - 1;
		res[i] |= 0 - (res[i] & (1 << (NTRU_S112_Q_BITS - 1)));
	}

}

//Shifting finite field from (0....p-1) to (-p/2.... p/2)
void simplePoly_ring_shift(int16_t poly[], int16_t p, int16_t n)
{
	int finalcoef;
	for (int i = 0; i < n; i++)
	{
		finalcoef = poly[i] % p;
		if (finalcoef > p / 2) finalcoef -= p;
		else if (finalcoef < -p / 2) finalcoef += p;
		poly[i] = finalcoef;
	}
}

// Record the positions of +1 and -1 into two different arrays
// pos	: store position of positive integer
// neg	: store position of negative integer
// polyA: array to be counted
// deg	: degree of polynomial
void countOne(uint16_t* pos, uint16_t* neg, int16_t* polyA, uint16_t deg)
{
	uint16_t countPos = 0, countNeg = 0;
	for (int i = 0; i < deg; i++)
	{
		if (polyA[i] == 1)
		{
			pos[countPos] = i;
			countPos++;
		}
		else if (polyA[i] == -1 || polyA[i] == 2047)
		{
			neg[countNeg] = i;
			countNeg++;
		}
	}
}


// Simple example from "NTRU PKCS Tutorial", 2014
void simpleNTRU()
{
#define N 11
#define Q 32
#define P 3

	int16_t * h, *e, *a, * c;
	int16_t* r, * m, * f, * fp;
	r = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	h = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	m = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	e = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	f = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	a = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	c = (int16_t*)malloc((N + 1) * sizeof(int16_t));
	fp = (int16_t*)malloc((N + 1) * sizeof(int16_t));

	for (int i = 0; i < 11; i++)
	{
		e[i] = 0;	a[i] = 0;	c[i] = 0;
	}

	// random polynomial of degree 10, three 1's three -1's, dr = 3
	r[0] = -1;	r[1] = 0;	r[2] = 1;	r[3] = 1;	r[4] = 1;
	r[5] = -1; 	r[6] = 0;	r[7] = -1;	r[8] = 0;	r[9] = 0;	r[10] = 0;

	// Public key h
	h[0] = 8;	h[1] = 25;	h[2] = 22;	h[3] = 20;	h[4] = 12;
	h[5] = 24; 	h[6] = 15;	h[7] = 19;	h[8] = 12;	h[9] = 19;	h[10] = 16;

	// message to be sent
	m[0] = -1;	m[1] = 0;	m[2] = 0;	m[3] = 1;	m[4] = -1;
	m[5] = 0; 	m[6] = 0;	m[7] = 0;	m[8] = -1;	m[9] = 1;	m[10] = 1;

	// Secret key f and fp
	f[0] = -1;	f[1] = 1;	f[2] = 1;	f[3] = 0;	f[4] = -1;
	f[5] = 0; 	f[6] = 1;	f[7] = 0;	f[8] = 0;	f[9] = 1;	f[10] = -1;

	fp[0] = 1;	fp[1] = 2;	fp[2] = 0;	fp[3] = 2;	fp[4] = 2;
	fp[5] = 1; 	fp[6] = 0;	fp[7] = 2;	fp[8] = 1;	fp[9] = 2;	fp[10] = 0;

	//	Encrypt e = r*h + m
	simplePolyMulModQ2(e, h, r, N, Q);
	simplePolyAddModQ(e, e, m, N, Q);
	printf("Encrypt Message\n");
	for (int i = 0; i < N; i++)		printf("%d\t", e[i]);

	// Decrypt a = f*e
	simplePolyMulModQ2(a, e, f, N, Q);
	simplePoly_ring_shift(a, Q, N);

	// b = a mod p, c = Fp *a
	//for (int i = 0; i<N; i++)	a[i] = a[i] % P;
	simplePoly_ring_shift(a, P, N);
	printf("\n");
	printf("\nDecrypt Message, m\n");
	simplePolyMulModQ2(c, a, fp, N, P);
	simplePoly_ring_shift(c, P, N);
	for (int i = 0; i < N; i++)		printf("%d\t", m[i]);
	for (int i = 0; i < N; i++)
	{
		if (m[i] != c[i]) {
			printf("wrong value at %u\n", i);
			break;
		}
	}

}

// NTRU-112 enc/dec
#define MSG_BYTE112 48
void test_NTRU_112()
{
	int16_t e[NTRU_N_112];
	int16_t m[NTRU_N_112];
	uint8_t data_enc[NTRU_ENCODE_BYTE]; // original plaintext to be encoded
	uint16_t i = 0;
	char buffer[50] = { 0 };
	int16_t *h, *f, *t;
	int16_t *r;
	h = (int16_t*)malloc(NTRU_N_112 * sizeof(int16_t));
	f = (int16_t*)malloc(NTRU_N_112 * sizeof(int16_t));
	r = (int16_t*)malloc(NTRU_N_112 * sizeof(int16_t));
	t = (int16_t*)malloc(2*NTRU_N_112 * sizeof(int16_t));

	memset(m, 0, NTRU_N_112*sizeof(int16_t));
	memset(r, 0, NTRU_N_112 * sizeof(int8_t));
	memset(e, 0, NTRU_N_112*sizeof(int16_t));
	memset(h, 0, NTRU_N_112 * sizeof(int16_t));	
	memset(f, 0, NTRU_N_112 * sizeof(int16_t));
	memset(t, 0, 2*NTRU_N_112 * sizeof(int16_t));

	printf("Start NTRU\r\n");
	printf("Key Generation:\r\n");
	int ret = keygeneration(f, h, t);
	if (ret) printf("Fail to generate keypair\n");
	else
	{
		//printf("\n Private Key f:\n");
		//for (i = 0; i < NTRU_N_112; i++) printf("%d\t", f[i]);
		//printf("\n Public Key h:\n");
		//for (i = 0; i < NTRU_N_112; i++) printf("%d\t", h[i]);
	}
	for (i = 0; i < NTRU_ENCODE_BYTE; i++)    data_enc[i] = i;
	//printf("\nMessage to Encode\r\n");
	//for (int i = 0; i < NTRU_ENCODE_BYTE; i++)
	//{
	//	if (i % 10 == 0)printf("\n");
	//	printf("%d,\t", data_enc[i]);
	//}
	ntruenc_encode_msg(data_enc, NTRU_ENCODE_BYTE, NTRU_N_112, m);
	//  Encrypt e = r*h + m	
	// First generate random vector r
	gen_random(r, NTRU_DF_112, NTRU_DF_112, 1);
	// Perform r*h
	poly_mul_mod_q(e, h, r);
	// Add with message vector m
	simplePolyAddModQ(e, e, m, NTRU_N_112, NTRU_Q_112);

	// Clear the buffer to store decrypted message
	memset(data_enc, 0, 48*sizeof(uint8_t));
	memset(m, 0, NTRU_N_112*sizeof(int16_t));

	//  Decrypt a = f*e
	poly_mul_mod_q(m, f, e);
	//  Calculate mod p to isolate the message/key.
	for (i = 0; i < NTRU_N_112; i++) m[i] = neg_mod_3_cpu[m[i] % 3];

	printf("\n\nDecoded Message\r\n");
	ntruenc_decode_msg(m, NTRU_N_112, data_enc);
	for (int i = 0; i < NTRU_ENCODE_BYTE; i++)
	{
		if (data_enc[i] != i)		
			printf("wrong at %d - %d \n", i, data_enc[i]);		
	}
	for (int i = 0; i < NTRU_ENCODE_BYTE; i++)
	{
		if (i % 10 == 0)printf("\n");
		printf("%d,\t", data_enc[i]);
	}

}

void test_speed_schoolbook_polynomial_multiplication()
{
	int16_t e[NTRU_N_112];
	int16_t m[NTRU_N_112];
	uint8_t data_enc[NTRU_ENCODE_BYTE]; // original plaintext to be encoded
	uint16_t i = 0;
	char buffer[50] = { 0 };
	clock_t time_req;
	double elapsed = 0;

	memset(m, 0, NTRU_N_112*sizeof(int16_t));
	memset(e, 0, NTRU_N_112 * sizeof(uint16_t));

	for (i = 0; i < NTRU_ENCODE_BYTE; i++)    data_enc[i] = i;
	ntruenc_encode_msg(data_enc, NTRU_ENCODE_BYTE, NTRU_N_112, m);
	printf("Start NTRU112 Speed Test: schoolbook polynomial multiplication\r\n");

	// Only profile the polynomial multiplication. 
	// Run multiple times for more accurate timing results.
	// Note that h112 and r112 are the pre-computed public key and random vector. They are being reused for many times.
	// In practice, r has to be generated separately for each encryption for security purpose.
	// 
	time_req = clock();

	//  Encrypt e = r*h + m
	for (i = 0; i < ITERATIONS; i++)
	{
		simplePolyMulModQ2(e, h112, r112, NTRU_N_112, NTRU_Q_112);
	}
	time_req = clock() - time_req;
	elapsed = (float)time_req / CLOCKS_PER_SEC;
	printf("\nTime take for %d Poly-Mult : %f [s]\n", ITERATIONS, elapsed);
}

void test_speed_sparse_polynomial_multiplication()
{
	uint16_t pos[NTRU_N_112];
	uint16_t neg[NTRU_N_112];
	int16_t e[NTRU_N_112];
	int16_t m[NTRU_N_112];
	uint8_t data_enc[NTRU_ENCODE_BYTE]; // original plaintext to be encoded
	uint16_t i = 0;
	char buffer[50] = { 0 };
	clock_t time_req;
	double elapsed = 0;

	memset(m, 0, NTRU_N_112 * sizeof(int16_t));
	memset(e, 0, NTRU_N_112 * sizeof(int16_t));
	memset(pos, 0, NTRU_N_112 * sizeof(uint16_t));
	memset(neg, 0, NTRU_N_112 * sizeof(uint16_t));

	for (i = 0; i < NTRU_ENCODE_BYTE; i++)    data_enc[i] = i;
	ntruenc_encode_msg(data_enc, NTRU_ENCODE_BYTE, NTRU_N_112, m);
	printf("Start NTRU112 Speed Test: sparse polynomial multiplication\r\n");

	// Only profile the polynomial multiplication. 
	// Run multiple times for more accurate timing results.
	time_req = clock();
	// Compute the positions of +1 and -1 in a polynomial
	countOne(pos, neg, r112, NTRU_N_112);
	//  Encrypt e = r*h + m
	for (i = 0; i < ITERATIONS; i++)
	{
		sparsePolyMulModQ(e, h112, r112, NTRU_N_112, NTRU_Q_112, pos, neg);
	}
	time_req = clock() - time_req;
	elapsed = (float)time_req / CLOCKS_PER_SEC;
	printf("\nTime take for %d Poly-Mult : %f [s]\n", ITERATIONS, elapsed);
}

int main(int argc, char** argv)
{
	int CPU_option = -1, GPU_option = -1, batch_size = 1;
	bool runtest = 0;
	for (int i = 1; i < argc;) {
		if (strcmp(argv[i], "-cpu") == 0) {
			CPU_option = atoi(argv[i + 1]);
			i += 2;
		}
	}

	if (CPU_option != -1)
	{
		if (CPU_option == 1)
			simpleNTRU();
		else if (CPU_option == 2)
			test_NTRU_112();
		else if (CPU_option == 3)
			test_speed_schoolbook_polynomial_multiplication();
		else if (CPU_option == 4)
			test_speed_sparse_polynomial_multiplication();
	}

	printf("\n\n");
	return 0;
}
